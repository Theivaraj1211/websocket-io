'use strict';
module.exports = {
  dbHost: process.env.PGDB_HOST || 'localhost',

  dbPort: process.env.PGDB_PORT || '6017',

  dbName: process.env.PGDB_DB || 'fts-app-v2',

  dbUser: process.env.PGDB_USERNAME || 'master',

  dbPassword: process.env.PGDB_PASSWORD || 'DHNNOQIYWMDZZPOQ',

  dbInsert: process.env.DB_INSERT || true,
  dbInsertInterval: process.env.DB_INSERT_INTERVAL || 3000,
  appPort: process.env.SSSS_SOCKET_PORT || 4043,
};
