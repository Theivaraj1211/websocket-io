'use strict';
// Import PostgrSQL
const { Client } = require('pg');
// Import Event Emitter
const EventEmitter = require('events');
// Import Config
const config = require('./config');
// Import util
const util = require('util');
// Import Express
const app = require('express')();
// Import Socket HTTP
const http = require('http').Server(app);
// Import socket.io
const io = require('socket.io')(http, {
  cors: {
    origin: '*',
  },
  transports: ['websocket', 'polling'],
});

(async () => {
  // DB Connection
  const client = new Client({
    host: config.dbHost,
    user: config.dbUser,
    password: config.dbPassword,
    database: config.dbName,
    port: config.dbPort,
  });
  try {
    await client.connect();
    console.log('DB connected!');
  } catch (e) {
    console.log('DB connection failed!');
  }

  // Build and instantiate custom event emitter
  function DbEventEmitter() {
    EventEmitter.call(this);
  }
  util.inherits(DbEventEmitter, EventEmitter);
  const dbEventEmitter = new DbEventEmitter();

  // Define the event handlers for each channel name
  dbEventEmitter.on('new_device', (msg) => {
    console.log('New device id: ' + msg.id);
  });

  // Inserting Data
  if (config.dbInsert == true) {
    function intervalFunc() {
      client.query(
        `INSERT INTO public.alerts
(alert_type_id, vehicle_id, alert, vehicle_no, description, severity, resolved, resolved_by, resolved_time, created_at, driver_id)
VALUES(1, 27, NULL, NULL, 'Out Of Geofence', 'Medium', false, NULL, NULL, '2023-04-10 15:37:44.117', 45);`,
        (err, res) => {
          console.log('inserted');
        }
      );
    }
    setInterval(intervalFunc, config.dbInsertInterval);
  }

  //Establish Connection via Socket
  io.on('connection', function (socket) {
    console.log('One User Connected  :', socket.id);
    dbEventEmitter.on('new_incidents', (msg) => {
      client.query(
        `select * from alerts i where i.id = ${msg.id}`,
        (err, res) => {
          const data = res.rows[0];
          console.log('incident id: ' + msg.id);
          socket.emit('message', { data: data });
        }
      );
    });
    socket.on('disconnect', function (response) {
      console.log('One User disconnected! : ', socket.id);
    });
  });

  // Listen for all pg_notify channel messages
  client.on('notification', function (msg) {
    let payload = JSON.parse(msg.payload);
    dbEventEmitter.emit(msg.channel, payload);
  });

  // Designate which channels we are listening on. Add additional channels with multiple lines.
  client.query('LISTEN new_incidents');
})();

http.listen(config.appPort, '0.0.0.0', function () {
  console.log(`listening : ${config.appPort}`);
});
